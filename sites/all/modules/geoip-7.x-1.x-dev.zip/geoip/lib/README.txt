GeoIP API Library
--------------------
The geoip module uses MaxMind's GeoIP PHP API to interact with the databases.
More information about the API can be found at http://www.maxmind.com/app/php.
